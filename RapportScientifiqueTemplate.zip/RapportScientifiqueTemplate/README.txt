1. pdflatex article
2. bitex article
3. pdflatex article
